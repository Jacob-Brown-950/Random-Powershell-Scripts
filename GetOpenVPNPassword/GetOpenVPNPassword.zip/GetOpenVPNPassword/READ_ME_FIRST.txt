The script will probably fail, so run these parameters before running it to make your life quicker. Don't worry if the first one fails, usually everything will still work: 

Set-ExecutionPolicy RemoteSigned

Add-Type -AssemblyName System.Security